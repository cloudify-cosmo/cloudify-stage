'use strict';

module.exports = function (r) {

    r.register('manager', 'GET', function (req, res, next, helper) {
        var _ = require('lodash');

        var jsonBody = require('body/json');
        var url = req.query.endpoint;
        var params = _.omit(req.query, 'endpoint');
        var headers = req.headers;

        jsonBody(req, res, function (error, body) {
            helper.Manager.doGet(url, params, headers).then(function (data) {
                return res.send(data);
            }).catch(next);
        });
    });

    r.register('request', 'GET', function (req, res, next, helper) {
        var _ = require('lodash');
        var url = req.query.url;
        var params = _.omit(req.query, 'url');
        helper.Request.doGet(url, params).then(function (data) {
            return res.send(data);
        }).catch(next);
    });
};
