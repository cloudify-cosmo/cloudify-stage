# Cloudify Hello World Example

[![Circle CI](https://circleci.com/gh/cloudify-cosmo/cloudify-hello-world-example/tree/master.svg?&style=shield)](https://circleci.com/gh/cloudify-cosmo/cloudify-hello-world-example/tree/master)

This repository contains a Hello World example blueprint based on OpenStack.

This example creates a VM on OpenStack and starts an HTTP server using a bash script.

If you're only now starting to work with Cloudify see our [Getting Started Guide](http://docs.getcloudify.org/latest/intro/getting-started/).
