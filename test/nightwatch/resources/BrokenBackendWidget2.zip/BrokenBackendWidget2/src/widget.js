import ManagerServiceDemo from './ManagerServiceDemo';

Stage.defineWidget({
    id: 'backendWidget',
    name: 'Backend Widget',
    description: 'Sample widget for widget backend support demo',
    initialWidth: 6,
    initialHeight: 26,
    showHeader: true,
    showBorder: true,
    isReact: true,
    categories: [Stage.GenericConfig.CATEGORY.OTHERS],
    permission: Stage.GenericConfig.CUSTOM_WIDGET_PERMISSIONS.CUSTOM_ALL,

    render: function(widget,data,error,toolbox) {
        return (
            <ManagerServiceDemo widgetBackend={toolbox.getWidgetBackend()}/>
        );
    }
});
