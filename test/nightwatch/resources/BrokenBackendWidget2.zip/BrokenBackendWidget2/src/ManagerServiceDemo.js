/**
 * Created by jakubniezgoda on 09/11/17.
 */

export default class ManagerServiceDemo extends React.Component {

    constructor(props,context) {
        super(props,context);

        this.methods = [
            {text: 'GET', value: 'get', key: 'get', func: 'doGet'},
            {text: 'POST', value: 'post', key: 'post', func: 'doPost'},
            {text: 'PUT', value: 'put', key: 'put', func: 'doPut'},
            {text: 'DELETE', value: 'delete', key: 'delete', func: 'doDelete'},
        ];

        this.managerServiceName = 'manager';

        this.state = {
            method: this.methods[0].value,
            endpoint: '',
            params: {},
            paramsCount: 0,
            payload: '',
            data: '',
            error: '',
            loading: false
        }
    }

    _onChange(event, field) {
        this.setState({[field.name]: field.value})
    }

    _onClick() {
        let method = _.find(this.methods, (method) => method.value === this.state.method);

        let params = {};
        for (var i = 0; i < this.state.paramsCount; i++) {
            if (this.state.params[i] && this.state.params[i].name) {
                params[this.state.params[i].name] = this.state.params[i].value;
            }
        }

        let endpoint = this.state.endpoint;

        let payload = true; // in case of doGet this value is sent as parseResponse argument
        if (!_.isEqual(this.state.method, this.methods[0].value) && !_.isEmpty(this.state.payload)){
            try {
                payload = JSON.parse(this.state.payload);
            } catch (error) {
                this.setState({error: 'Cannot parse payload. Error: ' + error});
                return;
            }
        }

        this.setState({loading: true})
        this.props.widgetBackend[method.func](this.managerServiceName, {endpoint, ...params}, payload)
            .then((data) => {
                this.setState({data, error: '', loading: false})
            }).catch((error) => {
                this.setState({data: '', error: error.status + ' - ' + error.message, loading: false})
            });
    }

    render() {
        var {Button, Dropdown, ErrorMessage, Input, HighlightText, Label, Loading, Popup, Segment, Table} = Stage.Basic;
        var data = this.state.data;

        return (
            <div>
                <Segment padded>
                    <Label attached='top'>Request</Label>
                    <Table compact basic='very'>
                        <Table.Body>
                            <Table.Row>
                                <Table.Cell collapsing>
                                    <Dropdown value={this.state.method} name="method" label='Method' selection closeOnChange compact
                                              onChange={this._onChange.bind(this)} options={this.methods} />
                                </Table.Cell>
                                <Table.Cell>
                                    <Popup>
                                        <Popup.Trigger>
                                            <Input value={this.state.endpoint} name="endpoint" label='http://<manager-ip>/api/v3.1/'
                                                   onChange={this._onChange.bind(this)} fluid placeholder='Cloudify REST API endpoint'/>
                                        </Popup.Trigger>
                                        See Cloudify REST API documentation for details about possible endpoints.
                                    </Popup>
                                </Table.Cell>
                                <Table.Cell collapsing>
                                    <Button content='Fire' icon='rocket' disabled={_.isEmpty(this.state.endpoint)}
                                            onClick={this._onClick.bind(this)} />
                                </Table.Cell>
                            </Table.Row>
                        </Table.Body>
                    </Table>
                </Segment>
                <Segment padded>
                    <Label attached='top'>Response</Label>
                    {
                        this.state.loading
                            ? <Loading />
                            : _.isEmpty(this.state.error)
                                ? <HighlightText>{_.isObject(data) ? JSON.stringify(data, null, 2) : data}</HighlightText>
                                : <ErrorMessage error={this.state.error} onDismiss={() => this.setState({error: ''})} />
                    }
                </Segment>
            </div>
        );
    }
}

