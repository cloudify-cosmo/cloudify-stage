(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
    "use strict";

    /**
     * Created by pawelposel on 03/11/2016.
     */

    Stage.defineWidget({
        name: "Test widget",
        description: 'Widget for testing',
        initialWidth: 2,
        initialHeight: 8,
        color: "blue",
        showHeader: false,
        isReact: true,
        permission: 'widget_custom_all',
        categories: [Stage.GenericConfig.CATEGORY.DEPLOYMENTS, Stage.GenericConfig.CATEGORY.CHARTS_AND_STATISTICS],

        initialConfiguration: [Stage.GenericConfig.POLLING_TIME_CONFIG(5)],
        fetchUrl: '[manager]/deployments?_include=id&_size=1',

        render: function render(widget, data, error, toolbox) {
            if (_.isEmpty(data)) {
                return React.createElement(Stage.Basic.Loading, null);
            }

            var num = _.get(data, "metadata.pagination.total", 0);
            var KeyIndicator = Stage.Basic.KeyIndicator;

            return React.createElement(KeyIndicator, { title: "Deployments", icon: "cube", number: num });
        }
    });

},{}]},{},[1])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJ3aWRnZXRzXFxkZXBsb3ltZW50TnVtXFxzcmNcXHdpZGdldC5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTs7O0FDQUE7Ozs7QUFJQSxNQUFNLFlBQU4sQ0FBbUI7QUFDZixRQUFJLGVBRFc7QUFFZixVQUFNLHVCQUZTO0FBR2YsaUJBQWEsdUJBSEU7QUFJZixrQkFBYyxDQUpDO0FBS2YsbUJBQWUsQ0FMQTtBQU1mLFdBQVEsT0FOTztBQU9mLGdCQUFZLEtBUEc7QUFRZixhQUFTLElBUk07QUFTZixnQkFBWSxhQVRHO0FBVWYsZ0JBQVksQ0FBQyxNQUFNLGFBQU4sQ0FBb0IsUUFBcEIsQ0FBNkIsV0FBOUIsRUFBMkMsTUFBTSxhQUFOLENBQW9CLFFBQXBCLENBQTZCLHFCQUF4RSxDQVZHOztBQVlmLDBCQUFzQixDQUNsQixNQUFNLGFBQU4sQ0FBb0IsbUJBQXBCLENBQXdDLENBQXhDLENBRGtCLENBWlA7QUFlZixjQUFVLDJDQWZLOztBQWlCZixZQUFRLGdCQUFTLE1BQVQsRUFBZ0IsSUFBaEIsRUFBcUIsS0FBckIsRUFBMkIsT0FBM0IsRUFBb0M7QUFDeEMsWUFBSSxFQUFFLE9BQUYsQ0FBVSxJQUFWLENBQUosRUFBcUI7QUFDakIsbUJBQU8sb0JBQUMsS0FBRCxDQUFPLEtBQVAsQ0FBYSxPQUFiLE9BQVA7QUFDSDs7QUFFRCxZQUFJLE1BQU0sRUFBRSxHQUFGLENBQU0sSUFBTixFQUFZLDJCQUFaLEVBQXlDLENBQXpDLENBQVY7QUFDQSxZQUFJLGVBQWUsTUFBTSxLQUFOLENBQVksWUFBL0I7O0FBRUEsZUFDSSxvQkFBQyxZQUFELElBQWMsT0FBTSxhQUFwQixFQUFrQyxNQUFLLE1BQXZDLEVBQThDLFFBQVEsR0FBdEQsR0FESjtBQUdIO0FBNUJjLENBQW5CIiwiZmlsZSI6ImdlbmVyYXRlZC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzQ29udGVudCI6WyIoZnVuY3Rpb24gZSh0LG4scil7ZnVuY3Rpb24gcyhvLHUpe2lmKCFuW29dKXtpZighdFtvXSl7dmFyIGE9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtpZighdSYmYSlyZXR1cm4gYShvLCEwKTtpZihpKXJldHVybiBpKG8sITApO3ZhciBmPW5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIrbytcIidcIik7dGhyb3cgZi5jb2RlPVwiTU9EVUxFX05PVF9GT1VORFwiLGZ9dmFyIGw9bltvXT17ZXhwb3J0czp7fX07dFtvXVswXS5jYWxsKGwuZXhwb3J0cyxmdW5jdGlvbihlKXt2YXIgbj10W29dWzFdW2VdO3JldHVybiBzKG4/bjplKX0sbCxsLmV4cG9ydHMsZSx0LG4scil9cmV0dXJuIG5bb10uZXhwb3J0c312YXIgaT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2Zvcih2YXIgbz0wO288ci5sZW5ndGg7bysrKXMocltvXSk7cmV0dXJuIHN9KSIsIi8qKlxyXG4gKiBDcmVhdGVkIGJ5IHBhd2VscG9zZWwgb24gMDMvMTEvMjAxNi5cclxuICovXHJcblxyXG5TdGFnZS5kZWZpbmVXaWRnZXQoe1xyXG4gICAgaWQ6IFwiZGVwbG95bWVudE51bVwiLFxyXG4gICAgbmFtZTogXCJOdW1iZXIgb2YgZGVwbG95bWVudHNcIixcclxuICAgIGRlc2NyaXB0aW9uOiAnTnVtYmVyIG9mIGRlcGxveW1lbnRzJyxcclxuICAgIGluaXRpYWxXaWR0aDogMixcclxuICAgIGluaXRpYWxIZWlnaHQ6IDgsXHJcbiAgICBjb2xvciA6IFwiZ3JlZW5cIixcclxuICAgIHNob3dIZWFkZXI6IGZhbHNlLFxyXG4gICAgaXNSZWFjdDogdHJ1ZSxcclxuICAgIHBlcm1pc3Npb246ICd3aWRnZXQtdXNlcicsXHJcbiAgICBjYXRlZ29yaWVzOiBbU3RhZ2UuR2VuZXJpY0NvbmZpZy5DQVRFR09SWS5ERVBMT1lNRU5UUywgU3RhZ2UuR2VuZXJpY0NvbmZpZy5DQVRFR09SWS5DSEFSVFNfQU5EX1NUQVRJU1RJQ1NdLFxyXG4gICAgXHJcbiAgICBpbml0aWFsQ29uZmlndXJhdGlvbjogW1xyXG4gICAgICAgIFN0YWdlLkdlbmVyaWNDb25maWcuUE9MTElOR19USU1FX0NPTkZJRyg1KVxyXG4gICAgXSxcclxuICAgIGZldGNoVXJsOiAnW21hbmFnZXJdL2RlcGxveW1lbnRzP19pbmNsdWRlPWlkJl9zaXplPTEnLFxyXG5cclxuICAgIHJlbmRlcjogZnVuY3Rpb24od2lkZ2V0LGRhdGEsZXJyb3IsdG9vbGJveCkge1xyXG4gICAgICAgIGlmIChfLmlzRW1wdHkoZGF0YSkpIHtcclxuICAgICAgICAgICAgcmV0dXJuIDxTdGFnZS5CYXNpYy5Mb2FkaW5nLz47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB2YXIgbnVtID0gXy5nZXQoZGF0YSwgXCJtZXRhZGF0YS5wYWdpbmF0aW9uLnRvdGFsXCIsIDApO1xyXG4gICAgICAgIGxldCBLZXlJbmRpY2F0b3IgPSBTdGFnZS5CYXNpYy5LZXlJbmRpY2F0b3I7XHJcblxyXG4gICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgIDxLZXlJbmRpY2F0b3IgdGl0bGU9XCJEZXBsb3ltZW50c1wiIGljb249XCJjdWJlXCIgbnVtYmVyPXtudW19Lz5cclxuICAgICAgICApO1xyXG4gICAgfVxyXG59KTsiXX0=
