'use strict';

var fs = require('fs-extra');

module.exports = function (r) {

    r.register('manager', 'POST', function (req, res, next, helper) {
        var _ = require('lodash');
        var jsonBody = require('body/json');
        var url = req.query.endpoint;
        var params = _.omit(req.query, 'endpoint');
        var headers = req.headers;

        jsonBody(req, res, function (error, body) {
            helper.Manager.doPost(url, params, body, headers).then(function (data) {
                return res.send(data);
            }).catch(next);
        });
    });

    r.register('manager', function (req, res, next, helper) {
        var _ = require('lodash');
        var url = req.query.endpoint;
        var params = _.omit(req.query, 'endpoint');
        var headers = req.headers;
        helper.Manager.doGet(url, params, headers).then(function (data) {
            return res.send(data);
        }).catch(next);
    });

    r.register('manager', 'PUT', function (req, res, next, helper) {
        var _ = require('lodash');
        var jsonBody = require('body/json');
        var url = req.query.endpoint;
        var params = _.omit(req.query, 'endpoint');
        var headers = req.headers;

        jsonBody(req, res, function (error, body) {
            helper.Manager.doPut(url, params, body, headers).then(function (data) {
                return res.send(data);
            }).catch(next);
        });
    });

    r.register('manager', 'DELETE', function (req, res, next, helper) {
        var _ = require('lodash');
        var url = req.query.endpoint;
        var params = _.omit(req.query, 'endpoint');
        var headers = req.headers;
        helper.Manager.doDelete(url, params, null, headers).then(function (data) {
            return res.send(data);
        }).catch(next);
    });

    r.register('request', 'POST', function (req, res, next, helper) {
        var _ = require('lodash');
        var jsonBody = require('body/json');
        var url = req.query.url;
        var params = _.omit(req.query, 'url');

        jsonBody(req, res, function (error, body) {
            helper.Request.doPost(url, params, body).then(function (data) {
                return res.send(data);
            }).catch(next);
        });
    });

    r.register('request', function (req, res, next, helper) {
        var _ = require('lodash');
        var url = req.query.url;
        var params = _.omit(req.query, 'url');
        helper.Request.doGet(url, params).then(function (data) {
            return res.send(data);
        }).catch(next);
    });

    r.register('request', 'PUT', function (req, res, next, helper) {
        var _ = require('lodash');
        var jsonBody = require('body/json');
        var url = req.query.url;
        var params = _.omit(req.query, 'url');

        jsonBody(req, res, function (error, body) {
            helper.Request.doPut(url, params, body).then(function (data) {
                return res.send(data);
            }).catch(next);
        });
    });

    r.register('request', 'DELETE', function (req, res, next, helper) {
        var _ = require('lodash');
        var url = req.query.url;
        var params = _.omit(req.query, 'url');
        helper.Request.doDelete(url, params).then(function (data) {
            return res.send(data);
        }).catch(next);
    });

    r.register('database', 'POST', function (req, res, next, helper) {
        helper.Database.create(req.query.key, req.query.value, req, res, next).then(function (data) {
            return res.send({ status: 'ok' });
        }).catch(next);
    });

    r.register('database', function (req, res, next, helper) {
        helper.Database.readAll(req, res, next).then(function (data) {
            return res.send({ items: data });
        }).catch(next);
    });

    r.register('database', 'PUT', function (req, res, next, helper) {
        helper.Database.update(req.query.key, req.query.value, req, res, next).then(function (data) {
            return res.send({ status: 'ok' });
        }).catch(next);
    });

    r.register('database', 'DELETE', function (req, res, next, helper) {
        helper.Database.remove(req.query.id, req, res, next).then(function (data) {
            return res.send({ status: 'ok' });
        }).catch(next);
    });
};
