import FileApiDemo from './FileApiDemo';

Stage.defineWidget({
    id: 'backendWidgetFsExtra',
    name: 'Backend Widget Fs Extra',
    description: 'Sample widget for widget backend fs-extra support demo',
    initialWidth: 6,
    initialHeight: 26,
    showHeader: true,
    showBorder: true,
    isReact: true,
    categories: [Stage.GenericConfig.CATEGORY.OTHERS],
    permission: Stage.GenericConfig.CUSTOM_WIDGET_PERMISSIONS.CUSTOM_ALL,
    render(_widget, _data, _error, toolbox) {
        return <FileApiDemo widgetBackend={toolbox.getWidgetBackend()} />;
    }
});