import type WidgetBackend from 'app/utils/WidgetBackend';
import React, { useState } from 'react';

type FileApiDemoProps = {
    widgetBackend: WidgetBackend;
};

export default function FileApiDemo({ widgetBackend }: FileApiDemoProps) {
    const [directoryPath, setDirectoryPath] = useState<string | undefined>(undefined);
    const [filePath, setFilePath] = useState<string | undefined>(undefined);
    const [data, setData] = useState<Record<string, any> | string | undefined>(undefined);
    const [error, setError] = useState<string | undefined>(undefined);
    const [loading, setLoading] = useState<boolean>(false);

    const onDirectoryPathChange = (_event: React.SyntheticEvent<HTMLInputElement>, field: { value: unknown }) => {
        setDirectoryPath(field.value as string);
    };

    const onFilePathChange = (_event: React.SyntheticEvent<HTMLInputElement>, field: { value: unknown }) => {
        setFilePath(field.value as string);
    };

    const onDirectoryReadClick = () => {
        setLoading(true);
        widgetBackend
            .doGet('readdirApi', { params: { path: directoryPath } })
            .then((response: Record<string, any>) => {
                setData(response);
                setError(undefined);
                setLoading(false);
            })
            .catch((err: Error) => {
                setData(undefined);
                setError(err.message);
                setLoading(false);
            });
    };

    const onFileReadClick = () => {
        setLoading(true);
        widgetBackend
            .doGet('readFileApi', { params: { path: filePath } })
            .then((response: string) => {
                setData(response);
                setError(undefined);
                setLoading(false);
            })
            .catch((err: Error) => {
                setData(undefined);
                setError(err.message);
                setLoading(false);
            });
    };

    const { Button, ErrorMessage, Input, HighlightText, Label, Popup, Loading, Segment, Table } = Stage.Basic;

    return (
        <div>
            <Segment padded>
                <Label attached="top">Request</Label>
                <Table compact basic="very">
                    <Table.Body>
                        <Table.Row>
                            <Table.Cell>
                                <Popup>
                                    <Popup.Trigger>
                                        <Input
                                            value={directoryPath}
                                            name="directoryPath"
                                            fluid
                                            onChange={onDirectoryPathChange}
                                        />
                                    </Popup.Trigger>
                                    You can use any directory path here.
                                </Popup>
                            </Table.Cell>
                            <Table.Cell collapsing>
                                <Button
                                    content="Read"
                                    disabled={_.isEmpty(directoryPath)}
                                    onClick={onDirectoryReadClick}
                                />
                            </Table.Cell>
                        </Table.Row>
                        <Table.Row>
                            <Table.Cell>
                                <Popup>
                                    <Popup.Trigger>
                                        <Input value={filePath} name="filePath" fluid onChange={onFilePathChange} />
                                    </Popup.Trigger>
                                    You can use any file path here.
                                </Popup>
                            </Table.Cell>
                            <Table.Cell collapsing>
                                <Button content="Read" disabled={_.isEmpty(filePath)} onClick={onFileReadClick} />
                            </Table.Cell>
                        </Table.Row>
                    </Table.Body>
                </Table>
            </Segment>
            <Segment padded>
                <Label attached="top">Response</Label>
                {loading && <Loading />}
                {!loading &&
                    (_.isEmpty(error) ? (
                        <HighlightText>{_.isObject(data) ? JSON.stringify(data, null, 2) : data}</HighlightText>
                    ) : (
                        <ErrorMessage error={error} onDismiss={() => setError(undefined)} />
                    ))}
            </Segment>
        </div>
    );
}
