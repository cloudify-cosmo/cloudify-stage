(function () {
  register(
    "readdirApi",
    "GET",
    `async function execute(query) {
        logger('info', JSON.stringify(query));
        const { path } = query;
        const files = await readdir.apply(
            undefined,
            [path],
            { result: { promise: true, copy: true } }
        );
        logger('info', JSON.stringify(files.map(file => file.name)));
        return JSON.stringify(files);
    }`
  );

  register(
    "readFileApi",
    "GET",
    `async function execute(query) {
        logger('info', JSON.stringify(query));
        const { path } = query;
        const content = await readFile.apply(
            undefined,
            [path],
            { result: { promise: true, copy: true } }
        );
        logger('info', content);
        return JSON.stringify(content);
    }`
  );
})();
