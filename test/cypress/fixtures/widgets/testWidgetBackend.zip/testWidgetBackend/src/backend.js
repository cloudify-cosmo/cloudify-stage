module.exports = function(r) {

    r.register('manager', 'GET', (req, res, next, helper) => {
        var _ = require('lodash');

        var jsonBody = require('body/json');
        var url = req.query.endpoint;
        var params = _.omit(req.query, 'endpoint');
        var headers = req.headers;

        jsonBody(req, res, function (error, body) {
            helper.Manager.doGet(url, params, headers)
                .then((data) => res.send(data))
                .catch(next);
        })
    });

    r.register('request', 'GET', (req, res, next, helper) => {
        var _ = require('lodash');
        var url = req.query.url;
        var params = _.omit(req.query, 'url');
        helper.Request.doGet(url, params)
            .then((data) => res.send(data))
            .catch(next);
    });

};
