(function () {
    register('request', 'GET', `async function execute(query) {
                    logger('info', JSON.stringify(query));
                    const { url } = query;
                    const { url: omitted, ...rest } = query;
                    const params = JSON.stringify(rest);
                    return await doGet.apply(
                        undefined,
                        ['request', url, params],
                        { result: { promise: true } }
                    );
                }`)
    
    register('manager', 'GET', `async function execute(query, reqHeaders) {
                    logger('info', JSON.stringify(query));
                    const url = query.endpoint;
                    const { endpoint: omitted, ...rest } = query;
                    const params = JSON.stringify(rest);
                    const headers = JSON.stringify(reqHeaders);
                    return await doGet.apply(
                        undefined,
                        ['manager', url, params, headers],
                        { result: { promise: true } }
                    );
                }`)
})();
