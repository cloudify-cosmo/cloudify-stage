import ManagerServiceDemo from './ManagerServiceDemo';

/**
 * Created by jakubniezgoda on 08/11/17.
 */

export default class RequestServiceDemo extends React.Component {
    constructor(props, context) {
        super(props, context);

        this.state = {
            url: '',
            data: '',
            error: '',
            loading: false
        };
    }

    onChange = (event, field) => {
        this.setState({ [field.name]: field.value });
    };

    onClick = () => {
        const { url } = this.state;
        const { widgetBackend } = this.props;

        this.setState({ loading: true });
        widgetBackend
            .doGet('request', { params: { url } })
            .then(data => {
                this.setState({ data, error: '', loading: false });
            })
            .catch(error => {
                this.setState({ data: '', error, loading: false });
            });
    };

    render() {
        const {
            Button,
            Dropdown,
            ErrorMessage,
            Input,
            HighlightText,
            Label,
            Loading,
            Popup,
            Segment,
            Table
        } = Stage.Basic;
        const { data, url, loading, error } = this.state;

        return (
            <div>
                <Segment padded>
                    <Label attached="top">Request</Label>
                    <Table compact basic="very">
                        <Table.Body>
                            <Table.Row>
                                <Table.Cell>
                                    <Popup>
                                        <Popup.Trigger>
                                            <Input value={url} name="url" label="URL" fluid onChange={this.onChange} />
                                        </Popup.Trigger>
                                        You can use any HTTP URL here.
                                    </Popup>
                                </Table.Cell>
                                <Table.Cell collapsing>
                                    <Button
                                        content="Fire"
                                        icon="rocket"
                                        disabled={_.isEmpty(url)}
                                        onClick={this.onClick}
                                    />
                                </Table.Cell>
                            </Table.Row>
                        </Table.Body>
                    </Table>
                </Segment>
                <Segment padded>
                    <Label attached="top">Response</Label>
                    {loading && <Loading />}
                    {!loading &&
                        (_.isEmpty(error) ? (
                            <HighlightText>{_.isObject(data) ? JSON.stringify(data, null, 2) : data}</HighlightText>
                        ) : (
                            <ErrorMessage error={error} onDismiss={() => this.setState({ error: '' })} />
                        ))}
                </Segment>
            </div>
        );
    }
}

RequestServiceDemo.propTypes = {
    widgetBackend: PropTypes.shape({
        doGet: PropTypes.func
    }).isRequired
};
