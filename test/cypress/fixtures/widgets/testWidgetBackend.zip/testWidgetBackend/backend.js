(function () {
  register(
    "request",
    "GET",
    `async function execute(query) {
                    logger('info', JSON.stringify(query));
                    const { url } = query;
                    const { url: omitted, ...params} = query;
                    const body = { key: 'value' };
                    const requestParams = JSON.stringify({ params, body });
                    return await doPost.apply(
                        undefined,
                        ['request', url, requestParams ],
                        { result: { promise: true } }
                    );
                }`
  );

  register(
    "request",
    "GET",
    `async function execute(query) {
                    logger('info', JSON.stringify(query));
                    const { url } = query;
                    const { url: omitted, ...params} = query;
                    const requestParams = JSON.stringify({ params});
                    return await doGet.apply(
                        undefined,
                        ['request', url, requestParams ],
                        { result: { promise: true } }
                    );
                }`
  );

  register(
    "manager",
    "GET",
    `async function execute(query, headers) {
                    logger('info', JSON.stringify(query));
                    const url = query.endpoint;
                    const { endpoint: omitted, ...params } = query;
                    const requestOptions = JSON.stringify({params, headers});
                    return await doGet.apply(
                        undefined,
                        ['manager', url, requestOptions ],
                        { result: { promise: true } }
                    );
                }`
  );
})();
