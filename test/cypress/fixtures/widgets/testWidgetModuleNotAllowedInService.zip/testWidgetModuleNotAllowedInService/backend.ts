'use strict';

export default function (r) {

    r.register('manager', 'GET', function (req, res, next, helper) {
        var fs = require('fs-extra');
        var _ = require('lodash');

        var jsonBody = require('body/json');
        var url = req.query.endpoint;
        var params = _.omit(req.query, 'endpoint');
        var headers = req.headers;

        jsonBody(req, res, function (error, body) {
            helper.Manager.doPost(url, params, body, headers).then(function (data) {
                return res.send(data);
            }).catch(next);
        });
    });
};
