/**
 * Created by jakubniezgoda on 09/11/17.
 */

export default class ManagerServiceDemo extends React.Component {
    constructor(props, context) {
        super(props, context);

        this.methods = [
            { text: 'GET', value: 'get', key: 'get', func: 'doGet' },
            { text: 'POST', value: 'post', key: 'post', func: 'doPost' },
            { text: 'PUT', value: 'put', key: 'put', func: 'doPut' },
            { text: 'DELETE', value: 'delete', key: 'delete', func: 'doDelete' }
        ];

        this.managerServiceName = 'manager';

        this.state = {
            method: this.methods[0].value,
            endpoint: '',
            params: {},
            paramsCount: 0,
            payload: '',
            data: '',
            error: '',
            loading: false
        };
    }

    onChange = (event, field) => {
        this.setState({ [field.name]: field.value });
    };

    onClick = () => {
        const { widgetBackend } = this.props;
        const { endpoint, paramsCount, params, payload, method } = this.state;

        const getParams = () => {
            const result = {};
            for (let i = 0; i < paramsCount; i += 1) {
                if (params[i] && params[i].name) {
                    result[params[i].name] = params[i].value;
                }
            }
            return result;
        };

        const getBody = () => {
            if (!_.isEqual(method, this.methods[0].value) && !_.isEmpty(payload)) {
                try {
                    return JSON.parse(payload);
                } catch (error) {
                    this.setState({ error: `Cannot parse payload. Error: ${error}` });
                }
            }
            return undefined;
        };

        this.setState({ loading: true });
        widgetBackend[_.find(this.methods, { value: method }).func](this.managerServiceName, {
            params: { ...getParams(), endpoint },
            body: getBody()
        })
            .then(data => {
                this.setState({ data, error: '', loading: false });
            })
            .catch(error => {
                this.setState({ data: '', error: `${error.status} - ${error.message}`, loading: false });
            });
    };

    render() {
        const {
            Button,
            Dropdown,
            ErrorMessage,
            Input,
            HighlightText,
            Label,
            Loading,
            Popup,
            Segment,
            Table
        } = Stage.Basic;
        const { data, method, endpoint, loading, error } = this.state;

        return (
            <div>
                <Segment padded>
                    <Label attached="top">Request</Label>
                    <Table compact basic="very">
                        <Table.Body>
                            <Table.Row>
                                <Table.Cell collapsing>
                                    <Dropdown
                                        value={method}
                                        name="method"
                                        label="Method"
                                        selection
                                        closeOnChange
                                        compact
                                        onChange={this.onChange}
                                        options={this.methods}
                                    />
                                </Table.Cell>
                                <Table.Cell>
                                    <Popup>
                                        <Popup.Trigger>
                                            <Input
                                                value={endpoint}
                                                name="endpoint"
                                                label="http://<manager-ip>/api/v3.1/"
                                                onChange={this.onChange}
                                                fluid
                                                placeholder="Cloudify REST API endpoint"
                                            />
                                        </Popup.Trigger>
                                        See Cloudify REST API documentation for details about possible endpoints.
                                    </Popup>
                                </Table.Cell>
                                <Table.Cell collapsing>
                                    <Button
                                        content="Fire"
                                        icon="rocket"
                                        disabled={_.isEmpty(endpoint)}
                                        onClick={this.onClick}
                                    />
                                </Table.Cell>
                            </Table.Row>
                        </Table.Body>
                    </Table>
                </Segment>
                <Segment padded>
                    <Label attached="top">Response</Label>
                    {loading && <Loading />}
                    {!loading &&
                        (_.isEmpty(error) ? (
                            <HighlightText>{_.isObject(data) ? JSON.stringify(data, null, 2) : data}</HighlightText>
                        ) : (
                            <ErrorMessage error={error} onDismiss={() => this.setState({ error: '' })} />
                        ))}
                </Segment>
            </div>
        );
    }
}

ManagerServiceDemo.propTypes = {
    widgetBackend: PropTypes.shape({
        doGet: PropTypes.func
    }).isRequired
};
