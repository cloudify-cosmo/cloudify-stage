(function () {
    register(
        'manager',
        'GET',
        `async function execute(query, headers) {
                    logger('info', JSON.stringify(query));
                    const url = query.endpoint;
                    const { endpoint: omitted, ...params } = query;
                    const requestOptions = JSON.stringify({params, headers});
                    return await doPostFull.apply(
                        undefined,
                        ['manager', url, requestOptions ],
                        { result: { promise: true } }
                    );
                }`
    );
})();
