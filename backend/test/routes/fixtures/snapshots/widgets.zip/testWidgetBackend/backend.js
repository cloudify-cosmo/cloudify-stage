module.exports = function (r) {
    r.register('manager', 'GET', (req, res, next, helper) => {
        const _ = require('lodash');

        const jsonBody = require('body/json');
        const url = req.query.endpoint;
        const params = _.omit(req.query, 'endpoint');
        const { headers } = req;

        jsonBody(req, res, function (error, body) {
            helper.Manager.doGet(url, { params, headers })
                .then(data => res.send(data))
                .catch(next);
        });
    });

    r.register('request', 'GET', (req, res, next, helper) => {
        const _ = require('lodash');
        const { url } = req.query;
        const params = _.omit(req.query, 'url');
        helper.Request.doGet(url, { params })
            .then(data => res.send(data))
            .catch(next);
    });
};
