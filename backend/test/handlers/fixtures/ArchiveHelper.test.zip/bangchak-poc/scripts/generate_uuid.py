from cloudify import ctx
import uuid

_uuid = uuid.uuid4()
ctx.instance.runtime_properties['uuid'] = str(_uuid)