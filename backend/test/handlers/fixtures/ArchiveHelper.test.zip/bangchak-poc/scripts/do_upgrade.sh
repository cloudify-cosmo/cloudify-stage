#!/bin/bash
sudo apt-get update && sudo apt-get -y upgrade